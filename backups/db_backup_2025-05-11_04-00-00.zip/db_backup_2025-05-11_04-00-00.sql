--
-- PostgreSQL database cluster dump
--

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE deals_user;
ALTER ROLE deals_user WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:/aCvKDyMq7EE2rN9mSkmdg==$XtwGvejosrtLOtA5NLrQa3rGgL4N5VPwWlGWEHps2fA=:oNvOmMHuLmCbhozwACBpeYwmEKig/g81WNs79lYltEQ=';

--
-- User Configurations
--








--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13 (Debian 15.13-1.pgdg120+1)
-- Dumped by pg_dump version 15.13 (Debian 15.13-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

--
-- Database "deals_db" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13 (Debian 15.13-1.pgdg120+1)
-- Dumped by pg_dump version 15.13 (Debian 15.13-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: deals_db; Type: DATABASE; Schema: -; Owner: deals_user
--

CREATE DATABASE deals_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE deals_db OWNER TO deals_user;

\connect deals_db

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: deals_user
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO deals_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: deal_suggestions; Type: TABLE; Schema: public; Owner: deals_user
--

CREATE TABLE public.deal_suggestions (
    suggestion_id integer NOT NULL,
    vendor_id integer,
    event_id integer,
    inventory_item_id integer,
    suggested_product_sku character varying(100),
    deal_details_prompt text,
    deal_details_suggestion_text text,
    suggested_discount_type character varying(20),
    suggested_discount_value numeric(10,2),
    original_price numeric(10,2),
    suggested_price numeric(10,2),
    ai_model_name character varying(100),
    ai_response_payload json,
    vendor_feedback character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    feedback_timestamp timestamp without time zone,
    status character varying(32) DEFAULT 'generated'::character varying NOT NULL,
    deals_api_request_payload json,
    deals_api_response_payload json,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT deal_suggestions_status_check CHECK (((status)::text = ANY ((ARRAY['generated'::character varying, 'notified_vendor'::character varying, 'feedback_received'::character varying, 'deal_posted'::character varying, 'deal_post_failed'::character varying, 'expired'::character varying])::text[]))),
    CONSTRAINT deal_suggestions_suggested_discount_type_check CHECK (((suggested_discount_type)::text = ANY ((ARRAY['percentage'::character varying, 'fixed_amount'::character varying])::text[]))),
    CONSTRAINT deal_suggestions_vendor_feedback_check CHECK (((vendor_feedback)::text = ANY ((ARRAY['pending'::character varying, 'accepted'::character varying, 'rejected'::character varying])::text[])))
);


ALTER TABLE public.deal_suggestions OWNER TO deals_user;

--
-- Name: deal_suggestions_suggestion_id_seq; Type: SEQUENCE; Schema: public; Owner: deals_user
--

CREATE SEQUENCE public.deal_suggestions_suggestion_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.deal_suggestions_suggestion_id_seq OWNER TO deals_user;

--
-- Name: deal_suggestions_suggestion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: deals_user
--

ALTER SEQUENCE public.deal_suggestions_suggestion_id_seq OWNED BY public.deal_suggestions.suggestion_id;


--
-- Name: events; Type: TABLE; Schema: public; Owner: deals_user
--

CREATE TABLE public.events (
    event_id integer NOT NULL,
    vendor_id integer,
    location_uuid uuid,
    event_trigger_point character varying(32) NOT NULL,
    event_details_text jsonb,
    event_location_latitude numeric(10,8),
    event_location_longitude numeric(11,8),
    event_timestamp timestamp without time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    processed_for_suggestion boolean DEFAULT false,
    CONSTRAINT events_event_trigger_point_check CHECK (((event_trigger_point)::text = ANY ((ARRAY['weather'::character varying, 'product_expiry'::character varying, 'holiday_special'::character varying, 'local_event'::character varying, 'competitor_action'::character varying, 'stock_level'::character varying])::text[])))
);


ALTER TABLE public.events OWNER TO deals_user;

--
-- Name: events_event_id_seq; Type: SEQUENCE; Schema: public; Owner: deals_user
--

CREATE SEQUENCE public.events_event_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.events_event_id_seq OWNER TO deals_user;

--
-- Name: events_event_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: deals_user
--

ALTER SEQUENCE public.events_event_id_seq OWNED BY public.events.event_id;


--
-- Name: inventory; Type: TABLE; Schema: public; Owner: deals_user
--

CREATE TABLE public.inventory (
    sku character varying(32) NOT NULL,
    product_name character varying(255) NOT NULL,
    description text,
    price numeric(10,2) NOT NULL,
    quantity_on_hand integer NOT NULL,
    category character varying(100) NOT NULL,
    supplier character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT inventory_price_check CHECK ((price > (0)::numeric)),
    CONSTRAINT inventory_quantity_on_hand_check CHECK ((quantity_on_hand >= 0))
);


ALTER TABLE public.inventory OWNER TO deals_user;

--
-- Name: deal_suggestions suggestion_id; Type: DEFAULT; Schema: public; Owner: deals_user
--

ALTER TABLE ONLY public.deal_suggestions ALTER COLUMN suggestion_id SET DEFAULT nextval('public.deal_suggestions_suggestion_id_seq'::regclass);


--
-- Name: events event_id; Type: DEFAULT; Schema: public; Owner: deals_user
--

ALTER TABLE ONLY public.events ALTER COLUMN event_id SET DEFAULT nextval('public.events_event_id_seq'::regclass);


--
-- Data for Name: deal_suggestions; Type: TABLE DATA; Schema: public; Owner: deals_user
--

COPY public.deal_suggestions (suggestion_id, vendor_id, event_id, inventory_item_id, suggested_product_sku, deal_details_prompt, deal_details_suggestion_text, suggested_discount_type, suggested_discount_value, original_price, suggested_price, ai_model_name, ai_response_payload, vendor_feedback, feedback_timestamp, status, deals_api_request_payload, deals_api_response_payload, created_at, updated_at) FROM stdin;
1	1	1	1	UMB-LG-BLK-001	Suggest a rainy day deal.	Buy a Large Black Umbrella at 20% off!	percentage	20.00	400.00	320.00	gemini-1.5-flash	{"model": "gemini-1.5-flash", "score": 0.98}	pending	\N	generated	\N	\N	2025-05-10 09:19:48.360569+00	2025-05-10 09:19:48.360569+00
2	2	2	2	WB-BRD-STL-002	Suggest a hydration deal.	Get a Branded Water Bottle for just ₹200!	fixed_amount	50.00	250.00	200.00	gemini-1.5-flash	{"model": "gemini-1.5-flash", "score": 0.95}	pending	\N	generated	\N	\N	2025-05-10 09:19:48.360569+00	2025-05-10 09:19:48.360569+00
3	3	3	3	EG-STR-PK-003	Suggest an energy deal.	Energy Gel pack of 3 at 10% off!	percentage	10.00	150.00	135.00	gemini-1.5-flash	{"model": "gemini-1.5-flash", "score": 0.92}	pending	\N	generated	\N	\N	2025-05-10 09:19:48.360569+00	2025-05-10 09:19:48.360569+00
4	4	4	4	CAP-RUN-BLU-004	Suggest a sun protection deal.	Running Cap - Blue at ₹150 only!	fixed_amount	30.00	180.00	150.00	gemini-1.5-flash	{"model": "gemini-1.5-flash", "score": 0.90}	pending	\N	generated	\N	\N	2025-05-10 09:19:48.360569+00	2025-05-10 09:19:48.360569+00
5	5	5	5	TSH-EVT-M-005	Suggest a t-shirt deal.	Event Branded T-Shirt (M) at 15% off!	percentage	15.00	350.00	297.50	gemini-1.5-flash	{"model": "gemini-1.5-flash", "score": 0.93}	pending	\N	generated	\N	\N	2025-05-10 09:19:48.360569+00	2025-05-10 09:19:48.360569+00
\.


--
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: deals_user
--

COPY public.events (event_id, vendor_id, location_uuid, event_trigger_point, event_details_text, event_location_latitude, event_location_longitude, event_timestamp, created_at, processed_for_suggestion) FROM stdin;
1	1	11111111-1111-1111-1111-111111111111	weather	{"description": "Heavy rain expected"}	28.61390000	77.20900000	2024-06-01 09:00:00	2025-05-10 09:19:48.355553+00	f
2	2	22222222-2222-2222-2222-222222222222	product_expiry	{"expiry": "2024-06-10", "product": "Energy Gel"}	19.07600000	72.87770000	2024-06-02 10:00:00	2025-05-10 09:19:48.355553+00	f
3	3	33333333-3333-3333-3333-333333333333	holiday_special	{"holiday": "Independence Day"}	12.97160000	77.59460000	2024-08-15 08:00:00	2025-05-10 09:19:48.355553+00	f
4	4	44444444-4444-4444-4444-444444444444	local_event	{"event": "Marathon"}	13.08270000	80.27070000	2024-07-20 06:00:00	2025-05-10 09:19:48.355553+00	f
5	5	55555555-5555-5555-5555-555555555555	stock_level	{"sku": "UMB-LG-BLK-001", "stock": 10}	22.57260000	88.36390000	2024-06-15 12:00:00	2025-05-10 09:19:48.355553+00	f
\.


--
-- Data for Name: inventory; Type: TABLE DATA; Schema: public; Owner: deals_user
--

COPY public.inventory (sku, product_name, description, price, quantity_on_hand, category, supplier, created_at, updated_at) FROM stdin;
UMB-LG-BLK-001	Large Black Umbrella	A sturdy black umbrella, windproof.	400.00	150	Accessories	Reliable Umbrellas Inc.	2025-05-10 09:19:48.358499+00	2025-05-10 09:19:48.358499+00
WB-BRD-STL-002	Water Bottle - Branded	Stainless steel, 750ml, event branded.	250.00	2000	Merchandise	PromoGoods Ltd.	2025-05-10 09:19:48.358499+00	2025-05-10 09:19:48.358499+00
EG-STR-PK-003	Energy Gel - Strawberry	Quick energy boost, strawberry flavor, pack of 3.	150.00	500	Consumables	Sports Nutrition Co.	2025-05-10 09:19:48.358499+00	2025-05-10 09:19:48.358499+00
CAP-RUN-BLU-004	Running Cap - Blue	Lightweight, breathable, adjustable blue cap.	180.00	300	Apparel	ActiveWear Supplies	2025-05-10 09:19:48.358499+00	2025-05-10 09:19:48.358499+00
TSH-EVT-M-005	T-Shirt - Event Branded - M	Cotton event t-shirt, medium size.	350.00	1500	Merchandise	PromoGoods Ltd.	2025-05-10 09:19:48.358499+00	2025-05-10 09:19:48.358499+00
TSH-EVT-L-006	T-Shirt - Event Branded - L	Cotton event t-shirt, large size.	350.00	1500	Merchandise	PromoGoods Ltd.	2025-05-10 09:19:48.358499+00	2025-05-10 09:19:48.358499+00
FAK-SML-RD-007	First Aid Kit - Small	Compact first aid kit for minor injuries.	220.00	100	Safety	HealthFirst Products	2025-05-10 09:19:48.358499+00	2025-05-10 09:19:48.358499+00
SUN-SPF50-100ML-008	Sunscreen SPF 50	100ml tube, SPF 50, water-resistant.	120.00	400	Consumables	SafeSkin Solutions	2025-05-10 09:19:48.358499+00	2025-05-10 09:19:48.358499+00
TWL-COOL-GRN-009	Cooling Towel	Instant cooling relief towel, green.	90.00	600	Accessories	ActiveWear Supplies	2025-05-10 09:19:48.358499+00	2025-05-10 09:19:48.358499+00
BAG-DRAW-RD-010	Drawstring Bag - Red	Nylon drawstring bag, red color, event logo option.	75.00	1000	Merchandise	PromoGoods Ltd.	2025-05-10 09:19:48.358499+00	2025-05-10 09:19:48.358499+00
\.


--
-- Name: deal_suggestions_suggestion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: deals_user
--

SELECT pg_catalog.setval('public.deal_suggestions_suggestion_id_seq', 5, true);


--
-- Name: events_event_id_seq; Type: SEQUENCE SET; Schema: public; Owner: deals_user
--

SELECT pg_catalog.setval('public.events_event_id_seq', 5, true);


--
-- Name: deal_suggestions deal_suggestions_pkey; Type: CONSTRAINT; Schema: public; Owner: deals_user
--

ALTER TABLE ONLY public.deal_suggestions
    ADD CONSTRAINT deal_suggestions_pkey PRIMARY KEY (suggestion_id);


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: public; Owner: deals_user
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (event_id);


--
-- Name: inventory inventory_pkey; Type: CONSTRAINT; Schema: public; Owner: deals_user
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_pkey PRIMARY KEY (sku);


--
-- Name: idx_deal_suggestions_event_id; Type: INDEX; Schema: public; Owner: deals_user
--

CREATE INDEX idx_deal_suggestions_event_id ON public.deal_suggestions USING btree (event_id);


--
-- Name: idx_deal_suggestions_inventory_item_id; Type: INDEX; Schema: public; Owner: deals_user
--

CREATE INDEX idx_deal_suggestions_inventory_item_id ON public.deal_suggestions USING btree (inventory_item_id);


--
-- Name: idx_deal_suggestions_status; Type: INDEX; Schema: public; Owner: deals_user
--

CREATE INDEX idx_deal_suggestions_status ON public.deal_suggestions USING btree (status);


--
-- Name: idx_deal_suggestions_vendor_feedback; Type: INDEX; Schema: public; Owner: deals_user
--

CREATE INDEX idx_deal_suggestions_vendor_feedback ON public.deal_suggestions USING btree (vendor_feedback);


--
-- Name: idx_deal_suggestions_vendor_id; Type: INDEX; Schema: public; Owner: deals_user
--

CREATE INDEX idx_deal_suggestions_vendor_id ON public.deal_suggestions USING btree (vendor_id);


--
-- Name: idx_events_location_uuid; Type: INDEX; Schema: public; Owner: deals_user
--

CREATE INDEX idx_events_location_uuid ON public.events USING btree (location_uuid);


--
-- Name: idx_events_processed_for_suggestion; Type: INDEX; Schema: public; Owner: deals_user
--

CREATE INDEX idx_events_processed_for_suggestion ON public.events USING btree (processed_for_suggestion);


--
-- Name: idx_events_trigger_point; Type: INDEX; Schema: public; Owner: deals_user
--

CREATE INDEX idx_events_trigger_point ON public.events USING btree (event_trigger_point);


--
-- Name: idx_events_vendor_id; Type: INDEX; Schema: public; Owner: deals_user
--

CREATE INDEX idx_events_vendor_id ON public.events USING btree (vendor_id);


--
-- Name: idx_inventory_category; Type: INDEX; Schema: public; Owner: deals_user
--

CREATE INDEX idx_inventory_category ON public.inventory USING btree (category);


--
-- Name: idx_inventory_supplier; Type: INDEX; Schema: public; Owner: deals_user
--

CREATE INDEX idx_inventory_supplier ON public.inventory USING btree (supplier);


--
-- Name: deal_suggestions update_deal_suggestions_updated_at; Type: TRIGGER; Schema: public; Owner: deals_user
--

CREATE TRIGGER update_deal_suggestions_updated_at BEFORE UPDATE ON public.deal_suggestions FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: events update_events_updated_at; Type: TRIGGER; Schema: public; Owner: deals_user
--

CREATE TRIGGER update_events_updated_at BEFORE UPDATE ON public.events FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: inventory update_inventory_updated_at; Type: TRIGGER; Schema: public; Owner: deals_user
--

CREATE TRIGGER update_inventory_updated_at BEFORE UPDATE ON public.inventory FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- PostgreSQL database dump complete
--

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13 (Debian 15.13-1.pgdg120+1)
-- Dumped by pg_dump version 15.13 (Debian 15.13-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database cluster dump complete
--

